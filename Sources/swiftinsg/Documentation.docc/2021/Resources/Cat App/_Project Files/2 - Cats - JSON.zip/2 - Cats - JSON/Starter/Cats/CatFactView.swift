//
//  CatFactView.swift
//  Cats
//
//  Created by JiaChen(: on 24/8/21.
//

import SwiftUI

struct CatFactView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CatFactView_Previews: PreviewProvider {
    static var previews: some View {
        CatFactView()
    }
}
