//
//  Firey_Flag_RaisingApp.swift
//  Firey Flag Raising
//
//  Created by jiachen on 3/9/21.
//

import SwiftUI

@main
struct Firey_Flag_RaisingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
