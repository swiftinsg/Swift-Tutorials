The Starter/Completed projects will not compile directly. Follow the tutorial and set up the Firebase Console and add the GoogleService-Info.plist into this Xcode Project.
