//
//  Flag_Raising_DemoApp.swift
//  Flag Raising Demo
//
//  Created by JiaChen(: on 12/6/21.
//

import SwiftUI

@main
struct Flag_Raising_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
