//
//  QuizApp.swift
//  Quiz
//
//  Created by JiaChen(: on 1/6/21.
//

import SwiftUI

@main
struct QuizApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
