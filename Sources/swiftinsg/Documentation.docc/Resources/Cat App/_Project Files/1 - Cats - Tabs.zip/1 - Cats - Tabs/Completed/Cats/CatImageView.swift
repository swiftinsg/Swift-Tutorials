//
//  CatImageView.swift
//  Cats
//
//  Created by JiaChen(: on 24/8/21.
//

import SwiftUI

struct CatImageView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CatImageView_Previews: PreviewProvider {
    static var previews: some View {
        CatImageView()
    }
}
