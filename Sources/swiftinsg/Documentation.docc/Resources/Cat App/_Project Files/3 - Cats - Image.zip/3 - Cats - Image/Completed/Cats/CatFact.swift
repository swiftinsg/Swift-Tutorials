import Foundation

struct CatFact: Decodable {
    var fact: String
    var length: Int
}
