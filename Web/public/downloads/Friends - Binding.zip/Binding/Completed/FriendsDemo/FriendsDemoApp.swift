//
//  FriendsDemoApp.swift
//  FriendsDemo
//
//  Created by JiaChen(: on 24/6/21.
//

import SwiftUI

@main
struct FriendsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
